DINSS NO MERCY — WEBSITE STARTER
=================================

ISI FOLDER
- index.html          Halaman utama website
- style.css           Desain dan tampilan responsif
- script.js           Tombol WhatsApp dan menu HP
- assets/dinss-logo.png  Logo konsep DINSS NO MERCY

CARA MEMBUKA
1. Ekstrak file ZIP ini.
2. Buka folder hasil ekstrak.
3. Klik dua kali index.html untuk melihat website di browser.
4. Internet diperlukan agar font online dapat dimuat.

SEBELUM DIPUBLIKASIKAN
1. Buka script.js dengan editor teks.
2. Ganti 628xxxxxxxxxx dengan nomor WhatsApp bisnis yang benar.
   Gunakan format Indonesia 62..., tanpa tanda +, spasi, atau tanda hubung.
3. Periksa dan ubah semua keterangan layanan agar sesuai layanan nyata.
4. Jangan memasang testimoni, alamat, harga, jam operasional, atau klaim
   yang belum benar-benar dimiliki/dapat dibuktikan.
5. Jika menambahkan layanan terkait akun game, periksa aturan penerbit game
   terlebih dahulu; beberapa penerbit membatasi atau melarang transfer akun.
6. Jangan meminta password atau OTP pelanggan.

PENTING
- Ini adalah website statis. Belum ada keranjang belanja, pembayaran,
  database, login pelanggan, atau dashboard admin.
- Untuk online, perlu domain/hosting atau layanan hosting statis.
- Gunakan informasi bisnis yang benar saat mengisi Meta Business.
- Pastikan orang tua/wali ikut membantu urusan kepemilikan, pembayaran,
  dan verifikasi bisnis jika diperlukan.
- Logo ini adalah konsep visual; nama dan merek game yang disebutkan
  adalah milik pemegang hak masing-masing.
